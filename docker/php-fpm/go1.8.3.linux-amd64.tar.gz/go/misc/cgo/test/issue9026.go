package cgotest

import (
	"testing"

	"./issue9026"
)

func test9026(t *testing.T) { issue9026.Test(t) }
